Once the game is installed, the easiest ways to get into a missions is:
Press Q - to select quick mission
Press A - to Accept
Press A - to Accept
please note: the F16 menus will appear jumbled.

F-16 Keychart

F1 - Toggle between Cockpit View and Hud Only View
F2 - Cockpit On/Off
F3 - External View
F4 - Fly-By View
F5 - Padlock View
F6 - Wingman External View
F7 - Missile View
F8 - Target View
F9 - Hud On/Off
F10 - Nav Display On/Off
F11 - nothing
F12 - 6x/1x Compression

Number Pad 9 - Right Console
Number Pad 8 - Cockpit View
Number Pad 7 - Left Console
Number Pad 6 - Right MFD
Number Pad 5 - Main Console
Number Pad 4 - Left MFD
Number Pad 3 - Joystick
Number Pad 2 - Center Console
Number Pad 1 - Throttle

5,6,7,8,9,0 - Throttle
- - Decrease Thrust
= - Increase Thrust
Backspace - Afterburner

Joystick Button 1 - Fire Current Weapon
Joystick Button 2 - Target
Joystick Button 3 - Move Camera
Joystick Button 4 - Select Weapon

Hat Switch Up - Cockpit
Hat Switch Right - Look Right
Hat Switch Left - Look Left
Hat Switch Down - Check 6

Number Pad / - Look Left
Number Pad * - Look Right
Number Pad - - Look Up
Number Pad + - Check 6

1 - AMRAM
2 - Sidewinder
3 - Cannon
4 - JDAM

Enter - Build Shootlist
Spacebar - Fire Current Weapon

B - Brake
G - Gear Up/Down
C - Counter Measures
L - Autoleveling
A - Autopilot
N - Cycle Waypoints
M - Mission Goals
[ - Previous Target
] - Next Target
; - Cycle Weapons
� - Boresight Target
, - Darken Hud
. - Lighten Hud
S - Zoom In
X - Zoom Out

T - Chat
Y- Message Log

Type �show codes� in chat bar to display various cheat and debug functions

