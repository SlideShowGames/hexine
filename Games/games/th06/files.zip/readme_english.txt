Touhou koumakyou ~ the Embodiment of Scarlet Devil
English translation patch version 0.8

Run th06e.exe to play the game in English.
Run custom_e.exe to change some advanced settings.

Translation from TouhouWiki, as of 2005-11-17
http://www.pooshlmer.com/touhouwiki/

Game patch by S" (Simon El�n)
http://www.shrinemaiden.com/BBS/viewtopic.php?t=406
