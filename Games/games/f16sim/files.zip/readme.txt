F-16 Multirole Fighter README

Contents:

	System Requirements
	Getting Started
	Multiplayer
	3DFX Support
	Keychart
        Technical Support


System Requirements:
====================
CPU: Pentium 120 mHz (3dfx card recommended)
Ram: 16 meg
OS: Windows 95


Getting Started:
================

The installer places icons to run the game, read this readme file, and 
to uninstall the game in your start menu.  To play F-16 you only need 
a mouse and keyboard.  A joystick is not required.  To start a single 
player mission, select Quick Mission.  The game will only load the 
single player mission available on this demo.  Select Accept to proceed.  
You can view the map or change your loadout if desired.  Hit Accept to 
begin the mission.


Multiplayer:
============

This demo only supports multiplayer on Novaworld.  To use NovaWorld you 
will need an internet connection.  The full version will provide other 
multiplayer options (serial, modem, LAN, and internet). Novaworld is the 
free online gaming site provided by NovaLogic.  From within the game, 
choose your "default browser" or our "mini-browser" to connect to Novaworld. 
Your play time on Novaworld will be limited.


3DFX Support:
=============

F-16 supports 3dfx compatable cards.  If you experience problems it may be 
because you do not have the correct Glide drivers.  If you have a Voodoo 1 
card, you need to have Glide 2.43 version drivers or greater.  If you have 
Voodoo 2, you need Glide 2.51 version drivers or greater.  These can be obtained 
from the 3dfx website at http://www.3dfx.com or from your card's manufacturer.


Keychart:
=========

Aircraft Control
----------------
Pitch Down			Forward Arrow	Joystick Forward
Pitch Up			Back Arrow	Joystick Back
Bank Left			Left Arrow	Joystick Left
Bank Right			Right Arrow	Joystick Right
Rudder Left			Delete		Rudder Left
Rudder Right			Page Down	Rudder Right
Brakes				B
Flaps Up/Down			F
Gear Up/Down			G

Targetting
----------
Create Shootlist		Enter
Next Target			Tab		Joystick Button 4
Cycle Targets Up/Down		[/]
Boresight Target		'

Weapons
-------
Fire Cannon			Z		Joystick Button 1
Fire Selected Weapon		Space		Joystick Button 2
Select Next Weapon		`		Joystick Button 3
Deselect Weapon			1
Select Cannon			2
Select Medium Range AAM		3
Select Short Range AAM		4
Select Medium Range AGM		Ctrl+1
Select Short Range AGM		Ctrl+2	
Select Bombs			Ctrl+3
Select Fuelpod			Ctrl+4

Views
-----
Cockpit View			F1
POV View			F2
Chase View			F3
Fly-By View			F4
Wingman View			F6
Target View			F8
Look Forward			Numpad -	Hat Forward
Look Left			Numpad /	Hat Left
Look Right			Numpad *	Hat Right
Check Six			Numpad +	Hat Back
HUD View			Numpad 8
Stick View			Numpad 3
Throttle View			Numpad 1

Avionics
--------
Attack Display			Numpad 6
Defense Display			Numpad 4
Artificial Horizon Display	Numpad 9
Navigation Display		Numpad 5
Status Display			Numpad 7
Stores Display			Numpad 2

Engines
-------
Engines Off			5
Throttle Idle			6
Throttle to 25%			7
Throttle to 50%			8
Throttle to 75%			9
Full Throttle			0
Full Afterburner		Backspace
Throttle Up/Down		-/=

Miscellaneous
-------------
Abort Mission			ESC
Auto Level			L
Eject				Ctrl+J
End Mission			End
HUD Brighten/Darken		,/.
HUD On/Off			F9
Jettison Stores			Ctrl+Z
Launch Chaff			C
Launch Flare			E
Mission Goals			M
Next Waypoint			N
Recent Messages			Y
Time Compression		F12
Wingman Commands		W

Multiplayer
-----------
Chat 				T
Squadron Chat			Ctrl+T
Player List			P
Score				K


Technical Support:
==================

If you are having a problem you need assistance with, check our websites 
(http://www.novalogic.com or http://novaworld.net) for up-to-date 
information on the product.  If you do not find the answer to your 
problem, you can contact us by the following means:

email: support@novalogic.com

When contacting us by email, note as completely as possible the nature 
of the problem and particulars about you system (CPU, speed, video and 
sound card types).
