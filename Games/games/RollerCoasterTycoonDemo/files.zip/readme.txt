*************************
ROLLERCOASTER TYCOON DEMO
*************************

This playable demo version of RollerCoaster Tycoon is limited to about
25 minutes of play time, after which it will revert to the title screen.

In addition, the following features are disabled:- Load/Save Game, Save
Track Design, most scenarios, some ride types, and ride music.

----------------------------------------------------------------------

� 1999 Hasbro Interactive. All rights reserved. This demo is a single
user license. It is not intended for duplication, mass distribution or
as a magazine covermount without the prior written permission of Hasbro
Interactive. Please contact your authorised Hasbro Interactive territory
representative for further information. Hasbro Interactive is a
registered trademark of Hasbro, Inc. All other trademarks are the
property of their respective holders and any individual rights or
trademarks are separately identified and recognised.



***************
Mini Play Guide
***************

Most game icons are self-explanetory, and leaving the mouse pointer stationery
on an icon displays a small pop-up message describing it's function.
The self-playing in-game tutorial can be selected from the title screen, and shows
how to start playing the game.

Main Landscape View
-------------------
The main landscape view is shown in any of 4 orientations and 3 zoom levels,
selected using the �rotate� and �zoom� icons at the top of the screen.
To move the view, position the mouse pointer on any area of the landscape,
hold the right mouse button down, then move the mouse to move the view. 
Alternatively, just move the mouse to the edge of the screen to scroll in that 
direction.

Building Rides and Attractions
------------------------------
Click the 'Build new ride/attractions' icon at the top of the screen, then select
the ride type from those available, and click 'Build this'. Some ride types have
pre-designed track designs available, or they can be custom-built from scratch.
For custom-designed tracks and simple ride types, the ride construction window
will be displayed, and you must choose a starting position for the ride or
attraction. For shops, stalls, and other 'all-in-one' rides, a grid of highlighted
blocks will follow the mouse pointer over the game landscape, showing the size of 
the initial construction area. Move the mouse pointer over the game landscape until
a suitable position is found, using the 'right-click to remove objects' function if
necessary, then click the left mouse button to attempt construction. When selecting
this initial construction position, the 'rotate' icon on the ride construction 
window can be used to rotate the ride/attraction footprint by 90 degrees. For
shops and stalls, the highlighted area on the game landscape indicates the direction
of the shop frontage by means of a large arrow. For track-based rides, this arrow
indicates the forward direction of the track to be built. Once the initial section
of ride track (or building) has been successfully constructed, the ride construction
window will change to allow either more ride track to be added, or the ride entrance
and exit to be built. For shops and stalls, once the building has been positioned,
the ride construction window will be replaced by the ride information window.
All rides and attractions except shops and stalls require entrance and exit buildings,
for guests to enter and leave the ride.

Building Footpaths and Queue Lines
----------------------------------
Click the footpath icon to display the footpath construction window.
There are two different �modes� for footpath construction, selected with the icons
at the bottom of the footpath window. The first mode (selected when the window is
first displayed), allows construction of footpaths directly on suitable flat land.
Simply move the mouse pointer over the game landscape until the required landscape
square is highlighted, then click the left mouse button. (While building footpaths,
the 'right-click to remove objects' function can be used to remove obstacles like
trees, and also to remove previously built sections of footpath).
The second mode (selected by selecting the bottom right icon in the path window)
allows construction of bridges and tunnels. When this mode is selected, the user
must select a starting position for the bridge. Move the mouse pointer over the 
game landscape and the yellow arrow shows the edge of the landscape square where
construction will start, and the direction of construction. To start footpath
construction from outside a ride entrance or exit, position the mouse pointer
over the entrance or exit. To start construction from the end or edge of an existing
footpath bridge or tunnel, position the highlighted square on the existing path,
with the arrow pointing in the direction construction is required. (For tunnel
construction, use the 'Underground View' option)



SYSTEM REQUIREMENTS
-------------------

Minimum System Requirements:

Pentium 90 CPU
Windows 95/98
16 MB RAM
4X CD ROM DRIVE
at least 55MB free hard drive space
1 MB SVGA card
Windows 95 compatible Sound Card
DirectX 5.0 
Mouse


Recommended System Requirements: (for good game performance)

Pentium 200 MMX CPU
Windows 95/98
32 MB RAM
8X CD ROM DRIVE
at least 55MB free hard drive space
2 MB accelerated SVGA card
Windows 95 compatible Sound Card
DirectX 5.0
Mouse


Ideal System Requirements: (for ultimate game performance)

Pentium II 350 CPU
Windows 95/98
64 MB RAM
8X CD ROM DRIVE
at least 180 MB free hard drive space
4 MB accelerated SVGA card
Windows 95 compatible Sound Card
DirectX 5.0 
Mouse



Installation Of Direct X:
-------------------------
RollerCoaster Tycoon requires DirectX 5.0 or higher in order to run. If you do not
have this installed on your computer, you will be prompted to install DirectX 5.0
while installing the game. Click "yes" when prompted to install DirectX 5.0 and
continue installing the game. If you have installed the minimum 'download' version
of this demo, and you don't already have DirectX 5.0 or higher on your machine, you
will need to obtain it before you can run the game. You can obtain it from the 
Microsoft website.




TROUBLESHOOTING
---------------

Problem: Crashing or lock-up with Creative Labs Sound Blaster 16 or AWE32 sound card on
 some machines.
Cure: Install the latest Creative Labs sound drivers.

Problem: Installing DirectX 5.0 causes the display to become unstable.
Cure: Boot up Windows 95 in safe-mode (press F8 while booting, then select safe mode),
 then remove all display drivers from System Properties, then re-boot and let Windows
 re-install the display drivers, or run Add New Hardware.
   
Problem: No sound or very quiet sound
Cure: Check the Windows sound volume and mute control and speaker connections.

Problem: Poor game performance when running the game in a window on the desktop or
 using 800x600 or 1024x768 resolutions
Cure: Use full-screen 640x480 resolution for best game performance.


----------------------------------------------------------------------
